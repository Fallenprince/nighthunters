## Prerequisites

Ensure that the following software is installed on your system:

- Git
- Golang
- Perl
- Python 3.x and Python 2.x
- Node.js and npm

The installation process will cover everything you need to run the tool.

## Installation Guide

### Step 1: Install the required dependencies

```bash
sudo apt-get install git -y
sudo apt-get install golang -y
sudo apt-get install perl -y
sudo apt-get install python3 -y
sudo apt-get install python2 -y
sudo apt-get install python3-pip -y
sudo apt-get install nodejs -y
sudo apt-get install npm -y
```

### Step 2: Clone the repository

```bash
git clone https://github.com/nwhsecurity/panel
cd panel/
```

### Step 3: Install Node.js packages

```bash
npm i requests
npm i https-proxy-agent
npm i crypto-random-string
npm i events
npm i fs
npm i net
npm i cloudscraper
npm i request
npm i hcaptcha-solver
npm i randomstring
npm i cluster
npm i cloudflare-bypasser
```

### Step 4: Install Google Chrome (for any web scraping or browser automation tasks)

```bash
wget https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb
sudo apt-get install ./google-chrome-stable_current_amd64.deb
```

### Step 5: Set file limit and permissions

```bash
ulimit -n 999999
chmod 777 *
```

### Step 6: Run the tool

```bash
python3 basicpanel.py
```
